// Copyright (C) 2012  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_SPaRSE_VECTOR_Hh_
#define DLIB_SPaRSE_VECTOR_Hh_ 

#include "svm/sparse_vector.h"

#endif // DLIB_SPaRSE_VECTOR_Hh_ 


